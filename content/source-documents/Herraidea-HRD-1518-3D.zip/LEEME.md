# Herraidea HRD 1518 · Borrador de despiece

Incluye GLB animado, visor de navegador y generador editable. Abra visor.html con conexión a Internet y WebGL. Arrastre para girar, use Despiece y Armar o el control de separación.

La ficha proporcionada indica poste de 2 pulgadas × 95 cm, vela articulada, montaje lateral y tres pines intermedios. La variante principal se cambió a montaje al piso por indicación del usuario. La variante lateral permanece como alternativa. Las barras y el pasamanos son contexto visual; no indican contenido del kit.

El montaje al piso incluye base solidaria al poste y tres tornillos con taquetes según la fotografía. Sus medidas y aptitud de anclaje no están especificadas. El soporte lateral, los pines y sus uniones internas son aproximados: faltan fotos de esas piezas desmontadas para reconstruirlos con fidelidad. No es un plano de fabricación ni una guía de instalación.

18 componentes o conjuntos con clip Despiece (0 a 3 segundos). Para web, cargar con GLTFLoader y AnimationMixer; tiempo 0 armado, 3 separado. Invertir el avance para ensamblar. extras.explode identifica los desplazamientos por nodo.

Se verificaron estructura binaria, número de componentes, canales de animación y sintaxis del visor. No se probó el visor en navegador en este entorno.

hrd-1518.glb: montaje al piso (23 conjuntos). hrd-1518-lateral.glb: montaje lateral (18 conjuntos). El selector del visor cambia entre ambos.
