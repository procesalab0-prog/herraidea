import math,struct,json,pathlib,zipfile,sys
LATERAL='--lateral' in sys.argv
P=pathlib.Path(__file__).parent
materials=[{'name':'Cristal transparente','pbrMetallicRoughness':{'baseColorFactor':[.90,.98,.96,1],'metallicFactor':0,'roughnessFactor':.07},'doubleSided':True,'extensions':{'KHR_materials_transmission':{'transmissionFactor':.97},'KHR_materials_ior':{'ior':1.5},'KHR_materials_volume':{'thicknessFactor':.012,'attenuationDistance':1.8,'attenuationColor':[.60,.92,.79]}}}, {'name':'Acero inoxidable','pbrMetallicRoughness':{'baseColorFactor':[.7,.73,.75,1],'metallicFactor':1,'roughnessFactor':.22}}, {'name':'Negro','pbrMetallicRoughness':{'baseColorFactor':[.016,.019,.022,1],'roughnessFactor':.43}}, {'name':'Blanco','pbrMetallicRoughness':{'baseColorFactor':[.91,.91,.88,1],'roughnessFactor':.32}}, {'name':'Lineas esmeriladas','pbrMetallicRoughness':{'baseColorFactor':[.7,.76,.73,1],'roughnessFactor':.8}}, {'name':'Balon naranja','pbrMetallicRoughness':{'baseColorFactor':[1,.19,.015,1],'roughnessFactor':.4}}]
groups={i:[[],[],[]] for i in range(6)}
parts={};active='';split=False;serial=0

def part(name,offset,separate=False):
 global active,split
 active=name;split=separate
 if name not in parts:parts[name]={'offset':offset,'groups':{}}

def mesh_part(v,n,f,m):
 global serial
 key=active
 if split:
  serial+=1;key=active+'_'+str(serial)
  center=[sum(q[i] for q in v)/len(v) for i in range(3)]
  off=parts[active]['offset']
  parts[key]={'offset':[off[i]+(center[i]-[0,.5,0][i])*.15 for i in range(3)],'groups':{}}
 d=parts[key]['groups'].setdefault(m,[[],[],[]]);k=len(d[0]);d[0].extend(v);d[1].extend(n);d[2].extend([k+i for i in f])

def mesh(v,n,f,m):
 mesh_part(v,n,f,m)
 a,b,c=groups[m]; k=len(a);a.extend(v);b.extend(n);c.extend([k+i for i in f])
def box(center,size,m):
 v=[];n=[];f=[]
 for ax in range(3):
  u=(ax+1)%3;w=(ax+2)%3
  for s in [-1,1]:
   k=len(v)
   for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]:
    q=list(center);q[ax]+=s*size[ax]/2;q[u]+=a*size[u]/2;q[w]+=b*size[w]/2;v.append(q);nn=[0,0,0];nn[ax]=s;n.append(nn)
   f.extend([k,k+1,k+2,k,k+2,k+3] if s==1 else [k,k+2,k+1,k,k+3,k+2])
 mesh(v,n,f,m)
def cyl(a,b,r,m,N=20):
 d=[b[i]-a[i] for i in range(3)];L=math.sqrt(sum(x*x for x in d));d=[x/L for x in d];t=[1,0,0] if abs(d[0])<.9 else [0,1,0]
 def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
 u=cross(d,t);l=math.sqrt(sum(x*x for x in u));u=[x/l for x in u];w=cross(d,u);v=[];n=[];f=[]
 for p in [a,b]:
  for j in range(N):
   t=2*math.pi*j/N;nn=[u[i]*math.cos(t)+w[i]*math.sin(t) for i in range(3)];v.append([p[i]+r*nn[i] for i in range(3)]);n.append(nn)
 for j in range(N):
  k=(j+1)%N;f.extend([j,k,N+k,j,N+k,N+j])
 for end,p in enumerate([a,b]):
  c=len(v);v.append(p);n.append([x*(2*end-1) for x in d])
  for j in range(N):
   k=(j+1)%N;f.extend([c,end*N+k,end*N+j] if end==0 else [c,end*N+j,end*N+k])
 mesh(v,n,f,m)
def sphere(c,r,m):
 v=[];n=[];f=[];N=20;R=12
 for i in range(R+1):
  t=math.pi*i/R
  for j in range(N+1):
   p=2*math.pi*j/N;q=[math.sin(t)*math.cos(p),math.cos(t),math.sin(t)*math.sin(p)];n.append(q);v.append([c[k]+r*q[k] for k in range(3)])
 for i in range(R):
  for j in range(N):
   k=i*(N+1)+j;f.extend([k,k+N+1,k+1,k+1,k+N+1,k+N+2])
 mesh(v,n,f,m)
def line(a,b):cyl(a,b,.002,4,8)
def prism(poly,axis,center,thickness,m):
 # Convex polygon extrusion; ordered counterclockwise in plane coordinates.
 u=(axis+1)%3;w=(axis+2)%3
 def point(q,t):
  v=[0,0,0];v[axis]=t;v[u]=q[0];v[w]=q[1];return v
 for sign in [-1,1]:
  v=[point(q,center+sign*thickness/2) for q in poly];n=[[sign if i==axis else 0 for i in range(3)]]*len(v);f=[]
  for j in range(1,len(v)-1):f.extend([0,j,j+1] if sign>0 else [0,j+1,j])
  mesh(v,n,f,m)
 for a,b in zip(poly,poly[1:]+poly[:1]):
  du=b[0]-a[0];dw=b[1]-a[1];l=math.hypot(du,dw);nn=[0,0,0];nn[u]=dw/l;nn[w]=-du/l
  v=[point(a,center-thickness/2),point(b,center-thickness/2),point(b,center+thickness/2),point(a,center+thickness/2)]
  mesh(v,[nn]*4,[0,1,2,0,2,3],m)
def chamfer_rect(a,b,c,d,r):
 return [(a+r,c),(b-r,c),(b,c+r),(b,d-r),(b-r,d),(a+r,d),(a,d-r),(a,c+r)]
# HRD1518: catalog tube diameter 2 inches and length .95m.
# Other geometry is approximate, not fabrication or anchoring design.
part('Poste_2_pulgadas_95cm',[0,0,0]);cyl([0,0,0],[0,.95,0],.0254,1,64)
part('Tapa_superior',[0,.05,0]);cyl([0,.95,0],[0,.954,0],.0254,1,64)
part('Vela_articulada',[0,.13,0]);cyl([0,.954,0],[0,1.015,0],.007,1,40)
part('Cuna_pasamanos',[0,.19,0]);cyl([0,1.012,-.011],[0,1.012,.011],.009,1,32);box([0,1.024,0],[.05,.004,.025],1)
part('Pasamanos_contexto',[0,.26,0]);cyl([-.42,1.049,0],[.42,1.049,0],.0254,1,64)
if LATERAL:
 part('Soporte_lateral_conjunto',[0,0,-.13]);cyl([0,.105,-.0254],[0,.105,-.085],.021,1,48);cyl([0,.105,-.085],[0,.105,-.093],.065,1,64)
else:
 # Floor flange stays rigidly joined to the post; three visible fixings per photo.
 part('Poste_2_pulgadas_95cm',[0,0,0]);cyl([0,-.006,0],[0,0,0],.06,1,64)
 for j in range(3):
  a=math.tau*j/3;x=.044*math.cos(a);z=.044*math.sin(a)
  part('Tornillo_base_'+str(j+1),[0,.08,0]);cyl([x,-.065,z],[x,.002,z],.003,1,24);cyl([x,.002,z],[x,.007,z],.006,1,6)
  part('Taquete_base_'+str(j+1),[0,-.07,0]);cyl([x,-.085,z],[x,-.035,z],.005,3,24)
for i,y in enumerate([.32,.55,.78],1):
 part('Pin_intermedio_'+str(i),[0,0,.08]);cyl([0,y,.02],[0,y,.065],.011,1,40)
 part('Cabeza_pin_'+str(i),[0,0,.16]);cyl([0,y,.065],[0,y,.071],.014,1,40)
 part('Prisionero_pin_'+str(i),[0,.045,.08]);cyl([0,y+.009,.048],[0,y+.014,.048],.0025,1,16)
 part('Barra_contexto_'+str(i),[.25,0,.08]);cyl([-.42,y,.048],[.42,y,.048],.006,1,40)
# glTF 2 binary export
blob=bytearray();views=[];access=[];meshes=[];nodes=[]
def add(data,typ,component,count,mins=None,maxs=None):
 while len(blob)%4:blob.append(0)
 off=len(blob);blob.extend(data);vi=len(views);views.append({'buffer':0,'byteOffset':off,'byteLength':len(data)})
 ac={'bufferView':vi,'componentType':component,'count':count,'type':typ}
 if mins is not None:ac.update(min=mins,max=maxs)
 access.append(ac);return len(access)-1
roots=[];animation_samplers=[];animation_channels=[]
times=add(struct.pack('<2f',0,3),'SCALAR',5126,2,[0],[3])
for name,partdata in parts.items():
 if not partdata['groups']:continue
 primitives=[]
 for m,(v,n,f) in partdata['groups'].items():
  assert len(v)==len(n) and max(f)<len(v)
  flat=lambda a:[x for q in a for x in q]
  pos=add(struct.pack('<%sf'%(len(v)*3),*flat(v)),'VEC3',5126,len(v),[min(q[i] for q in v) for i in range(3)],[max(q[i] for q in v) for i in range(3)])
  norm=add(struct.pack('<%sf'%(len(n)*3),*flat(n)),'VEC3',5126,len(n))
  ind=add(struct.pack('<%sI'%len(f),*f),'SCALAR',5125,len(f))
  primitives.append({'attributes':{'POSITION':pos,'NORMAL':norm},'indices':ind,'material':m})
 mi=len(meshes);meshes.append({'name':name,'primitives':primitives})
 ni=len(nodes);nodes.append({'mesh':mi,'name':name,'translation':[0,0,0],'extras':{'explode':partdata['offset'],'part':True}});roots.append(ni)
 vals=add(struct.pack('<6f',0,0,0,*partdata['offset']),'VEC3',5126,2)
 animation_samplers.append({'input':times,'output':vals,'interpolation':'LINEAR'})
 animation_channels.append({'sampler':len(animation_samplers)-1,'target':{'node':ni,'path':'translation'}})
doc={'asset':{'version':'2.0','generator':'Herraidea parts reconstruction','extras':{'note':'Approximate photo-based geometry. Exploded animation for presentation, not mechanical assembly instructions.'}},'scene':0,'scenes':[{'nodes':roots}],'nodes':nodes,'meshes':meshes,'materials':materials,'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':access,'animations':[{'name':'Despiece','samplers':animation_samplers,'channels':animation_channels}],'extensionsUsed':['KHR_materials_transmission','KHR_materials_ior','KHR_materials_volume']}
print(len(roots),'independently addressable parts; embedded Despiece animation')
j=json.dumps(doc,separators=(',',':'),ensure_ascii=True).encode();j+=b' '*((-len(j))%4);blob+=b'\0'*((-len(blob))%4)
raw=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
(P/('hrd-1518-lateral.glb' if LATERAL else 'hrd-1518.glb')).write_bytes(raw)
assert struct.unpack_from('<I',raw,8)[0]==len(raw)
print('GLB:',len(raw),'bytes;',sum(len(g[2])//3 for g in groups.values()),'triangles')
