import math,struct,json,pathlib,zipfile
P=pathlib.Path(__file__).parent
materials=[{'name':'Cristal transparente','pbrMetallicRoughness':{'baseColorFactor':[.90,.98,.96,1],'metallicFactor':0,'roughnessFactor':.07},'doubleSided':True,'extensions':{'KHR_materials_transmission':{'transmissionFactor':.97},'KHR_materials_ior':{'ior':1.5},'KHR_materials_volume':{'thicknessFactor':.012,'attenuationDistance':1.8,'attenuationColor':[.60,.92,.79]}}}, {'name':'Acero inoxidable','pbrMetallicRoughness':{'baseColorFactor':[.7,.73,.75,1],'metallicFactor':1,'roughnessFactor':.22}}, {'name':'Negro','pbrMetallicRoughness':{'baseColorFactor':[.016,.019,.022,1],'roughnessFactor':.43}}, {'name':'Blanco','pbrMetallicRoughness':{'baseColorFactor':[.91,.91,.88,1],'roughnessFactor':.32}}, {'name':'Lineas esmeriladas','pbrMetallicRoughness':{'baseColorFactor':[.7,.76,.73,1],'roughnessFactor':.8}}, {'name':'Balon naranja','pbrMetallicRoughness':{'baseColorFactor':[1,.19,.015,1],'roughnessFactor':.4}}]
groups={i:[[],[],[]] for i in range(6)}
parts={};active='';split=False;serial=0

def part(name,offset,separate=False):
 global active,split
 active=name;split=separate
 if name not in parts:parts[name]={'offset':offset,'groups':{}}

def mesh_part(v,n,f,m):
 global serial
 key=active
 if split:
  serial+=1;key=active+'_'+str(serial)
  center=[sum(q[i] for q in v)/len(v) for i in range(3)]
  off=parts[active]['offset']
  parts[key]={'offset':[off[i]+(center[i]-[0,.5,0][i])*.15 for i in range(3)],'groups':{}}
 d=parts[key]['groups'].setdefault(m,[[],[],[]]);k=len(d[0]);d[0].extend(v);d[1].extend(n);d[2].extend([k+i for i in f])

def mesh(v,n,f,m):
 mesh_part(v,n,f,m)
 a,b,c=groups[m]; k=len(a);a.extend(v);b.extend(n);c.extend([k+i for i in f])
def box(center,size,m):
 v=[];n=[];f=[]
 for ax in range(3):
  u=(ax+1)%3;w=(ax+2)%3
  for s in [-1,1]:
   k=len(v)
   for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]:
    q=list(center);q[ax]+=s*size[ax]/2;q[u]+=a*size[u]/2;q[w]+=b*size[w]/2;v.append(q);nn=[0,0,0];nn[ax]=s;n.append(nn)
   f.extend([k,k+1,k+2,k,k+2,k+3] if s==1 else [k,k+2,k+1,k,k+3,k+2])
 mesh(v,n,f,m)
def cyl(a,b,r,m,N=20):
 d=[b[i]-a[i] for i in range(3)];L=math.sqrt(sum(x*x for x in d));d=[x/L for x in d];t=[1,0,0] if abs(d[0])<.9 else [0,1,0]
 def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
 u=cross(d,t);l=math.sqrt(sum(x*x for x in u));u=[x/l for x in u];w=cross(d,u);v=[];n=[];f=[]
 for p in [a,b]:
  for j in range(N):
   t=2*math.pi*j/N;nn=[u[i]*math.cos(t)+w[i]*math.sin(t) for i in range(3)];v.append([p[i]+r*nn[i] for i in range(3)]);n.append(nn)
 for j in range(N):
  k=(j+1)%N;f.extend([j,k,N+k,j,N+k,N+j])
 for end,p in enumerate([a,b]):
  c=len(v);v.append(p);n.append([x*(2*end-1) for x in d])
  for j in range(N):
   k=(j+1)%N;f.extend([c,end*N+k,end*N+j] if end==0 else [c,end*N+j,end*N+k])
 mesh(v,n,f,m)
def sphere(c,r,m):
 v=[];n=[];f=[];N=20;R=12
 for i in range(R+1):
  t=math.pi*i/R
  for j in range(N+1):
   p=2*math.pi*j/N;q=[math.sin(t)*math.cos(p),math.cos(t),math.sin(t)*math.sin(p)];n.append(q);v.append([c[k]+r*q[k] for k in range(3)])
 for i in range(R):
  for j in range(N):
   k=i*(N+1)+j;f.extend([k,k+N+1,k+1,k+1,k+N+1,k+N+2])
 mesh(v,n,f,m)
def line(a,b):cyl(a,b,.002,4,8)
def prism(poly,axis,center,thickness,m):
 # Convex polygon extrusion; ordered counterclockwise in plane coordinates.
 u=(axis+1)%3;w=(axis+2)%3
 def point(q,t):
  v=[0,0,0];v[axis]=t;v[u]=q[0];v[w]=q[1];return v
 for sign in [-1,1]:
  v=[point(q,center+sign*thickness/2) for q in poly];n=[[sign if i==axis else 0 for i in range(3)]]*len(v);f=[]
  for j in range(1,len(v)-1):f.extend([0,j,j+1] if sign>0 else [0,j+1,j])
  mesh(v,n,f,m)
 for a,b in zip(poly,poly[1:]+poly[:1]):
  du=b[0]-a[0];dw=b[1]-a[1];l=math.hypot(du,dw);nn=[0,0,0];nn[u]=dw/l;nn[w]=-du/l
  v=[point(a,center-thickness/2),point(b,center-thickness/2),point(b,center+thickness/2),point(a,center+thickness/2)]
  mesh(v,[nn]*4,[0,1,2,0,2,3],m)
def chamfer_rect(a,b,c,d,r):
 return [(a+r,c),(b-r,c),(b,c+r),(b,d-r),(b-r,d),(a+r,d),(a,d-r),(a,c+r)]
# Separate glass pieces with chamfered corners and visible corner clearance.
part('Cristal_cancha',[0,.42,0])
prism(chamfer_rect(-.39,.39,-.645,.645,.025),1,.8,.012,0)
def side_panel(z):
 # Single closed concave profile, extruded as one uninterrupted sheet.
 poly=[(-.636,.035),(-.54,.035),(-.54,.622)]
 for i in range(1,17):
  t=math.pi-i*math.pi/32;poly.append((-.46+.08*math.cos(t),.622+.08*math.sin(t)))
 poly.append((.46,.702))
 for i in range(1,17):
  t=math.pi/2-i*math.pi/32;poly.append((.46+.08*math.cos(t),.622+.08*math.sin(t)))
 poly.extend([(.54,.035),(.636,.035),(.636,.962),(.606,.992),(-.606,.992),(-.636,.962)])
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 ids=list(range(len(poly)));tri=[]
 while len(ids)>3:
  found=False
  for j in range(len(ids)):
   a,b,c=ids[j-1],ids[j],ids[(j+1)%len(ids)]
   if cross(poly[a],poly[b],poly[c])<=1e-12:continue
   if any(all(cross(poly[u],poly[v],poly[k])>=-1e-12 for u,v in [(a,b),(b,c),(c,a)]) for k in ids if k not in [a,b,c]):continue
   tri.append((a,b,c));ids.pop(j);found=True;break
  assert found,'Could not triangulate lateral glass'
 tri.append(tuple(ids))
 for sign in [-1,1]:
  v=[[x,y,z+sign*.006] for x,y in poly];f=[]
  for a,b,c in tri:f.extend([a,b,c] if sign>0 else [a,c,b])
  mesh(v,[[0,0,sign]]*len(v),f,0)
 for a,b in zip(poly,poly[1:]+poly[:1]):
  dx=b[0]-a[0];dy=b[1]-a[1];L=math.hypot(dx,dy)
  v=[[a[0],a[1],z-.006],[b[0],b[1],z-.006],[b[0],b[1],z+.006],[a[0],a[1],z+.006]]
  mesh(v,[[dy/L,-dx/L,0]]*4,[0,1,2,0,2,3],0)
for z in [-.406,.406]:
 part('Cristal_lateral_completo_'+str(z),[0,0,math.copysign(.48,z)])
 side_panel(z)
# One continuous end glass panel per goal, with rounded U cutout below
# and an aperture for the ball. Faces share positions; no internal seams.
def end_panel(x):
 zs=sorted(set([-.394,.394,-.364,.364,-.31,.31,-.25,.25,-.155,.155]+[sg*(.25+.06*i/16) for sg in [-1,1] for i in range(17)]))
 def lower(z):
  az=abs(z)
  if az>=.31:return .035
  if az<=.25:return .70
  return .64+math.sqrt(max(0,.06**2-(az-.25)**2))
 faces=[]
 for za,zb in zip(zs,zs[1:]):
  # Last strip connects the vertical inner leg to the rounded corner.
  la=lower(za);lb=lower(zb)
  if abs(za)==.31 and abs(zb)<.31:la=.64
  if abs(zb)==.31 and abs(za)<.31:lb=.64
  levels=[(la,lb),(.735,.735),(.80,.80),(.91,.91),(.967-max(0,abs(za)-.364),.967-max(0,abs(zb)-.364))]
  for k in range(len(levels)-1):
   if k==2 and za>=-.155 and zb<=.155:continue
   ya,yb=levels[k];ua,ub=levels[k+1]
   faces.append([(za,ya),(zb,yb),(zb,ub),(za,ua)])
 # Exposed edges only: cancel shared edges to avoid internal glass planes.
 edges={}
 for poly in faces:
  for a,b in zip(poly,poly[1:]+poly[:1]):
   key=tuple(sorted((a,b)))
   edges[key]=edges.get(key,0)+1
  for sign in [-1,1]:
   v=[[x+sign*.006,y,z] for z,y in poly]
   mesh(v,[[sign,0,0]]*4,[0,1,2,0,2,3] if sign<0 else [0,2,1,0,3,2],0)
 for (a,b),count in edges.items():
  if count!=1:continue
  za,ya=a;zb,yb=b;dy=yb-ya;dz=zb-za;L=math.hypot(dy,dz)
  v=[[x-.006,ya,za],[x+.006,ya,za],[x+.006,yb,zb],[x-.006,yb,zb]]
  mesh(v,[[0,dz/L,-dy/L]]*4,[0,1,2,0,2,3],0)
for x in [-.654,.654]:
 part('Cristal_cabecera_'+str(x),[math.copysign(.50,x),0,0]);end_panel(x)
for x in [-.59,.59]:
 for z in [-.40,.40]:
  part('Herraje_superior_'+str(x)+'_'+str(z),[math.copysign(.30,x),.15,math.copysign(.30,z)],True)
  # Upper corner connector: two horizontal arms, vertical support to field.
  sx=math.copysign(1,x);sz=math.copysign(1,z)
  ux=x;uz=z-sz*.060;uy=.745
  cyl([ux,uy,uz],[ux,.795,uz],.022,1,48)
  cyl([ux,.791,uz],[ux,.798,uz],.027,2,48)
  for axis,sgn in [(0,sx),(2,sz)]:
   def upper(t):
    q=[ux,uy,uz];q[axis]+=sgn*t;return q
   cyl(upper(0),upper(.051),.027,1,48)
   cyl(upper(.051),upper(.059),.028,2,48)
   cyl(upper(.059),upper(.072),.031,1,48)
  part('Pipeta_inferior_'+str(x)+'_'+str(z),[math.copysign(.30,x),-.025,math.copysign(.30,z)],True)
  # Lower corner fitting: perpendicular cylindrical arms and black gaskets.
  sx=math.copysign(1,x);sz=math.copysign(1,z)
  cx=x;cz=z-sz*.060;cy=.112
  cyl([cx,.025,cz],[cx,.133,cz],.023,1,48)
  cyl([cx,.009,cz],[cx,.025,cz],.033,2,48)
  for axis,sgn in [(0,sx),(2,sz)]:
   def arm(t):
    q=[cx,cy,cz];q[axis]+=sgn*t;return q
   cyl(arm(0),arm(.051),.027,1,48)
   cyl(arm(.047),arm(.052),.029,1,48)
   cyl(arm(.052),arm(.059),.028,2,48)
   cyl(arm(.059),arm(.072),.031,1,48)
   cyl(arm(.072),arm(.074),.0295,1,48)
# pitch
part('Cristal_cancha',[0,.42,0])
Y=.807
for z in [-.34,.34]:line([-.63,Y,z],[.63,Y,z])
for x in [-.63,0,.63]:line([x,Y,-.34],[x,Y,.34])
for j in range(72):
 a=2*math.pi*j/72;b=2*math.pi*(j+1)/72;line([.125*math.cos(a),Y,.125*math.sin(a)],[.125*math.cos(b),Y,.125*math.sin(b)])
for s in [-1,1]:
 line([s*.43,Y,-.22],[s*.43,Y,.22])
 for z in [-.22,.22]:line([s*.43,Y,z],[s*.63,Y,z])
# eight rods and 22 players, matching reference rows 1/3/3/4/4/3/3/1 = 22
for idx,(count,col) in enumerate([(1,3),(3,3),(3,2),(4,3),(4,2),(3,3),(3,2),(1,2)]):
 x=-.59+idx*1.18/7;yy=.911;side=-1 if col==3 else 1
 part('Barra_'+str(idx),[x*.5,.65,0])
 cyl([x,yy,-.56],[x,yy,.56],.007,1,24)
 part('Mango_'+str(idx),[x*.5,.65,side*.50])
 cyl([x,yy,side*.52],[x,yy,side*.69],.018,1,32)
 for z in [-.409,.409]:
  part('Pasabarras_'+str(idx)+'_'+str(z),[x*.5,.46,math.copysign(.70,z)],True)
  cyl([x,yy,z-.014],[x,yy,z-.008],.028,1,32)
  cyl([x,yy,z-.008],[x,yy,z+.008],.022,2,32)
  cyl([x,yy,z+.008],[x,yy,z+.014],.028,1,32)
  part('Resorte_'+str(idx)+'_'+str(z),[x*.5,.60,math.copysign(.30,z)])
  for t in range(60):
   a=t*math.pi/6;b=(t+1)*math.pi/6;zz=z-math.copysign(.035,z)-math.copysign(t*.0007,z);zz2=z-math.copysign(.035,z)-math.copysign((t+1)*.0007,z)
   cyl([x+.011*math.cos(a),yy+.011*math.sin(a),zz],[x+.011*math.cos(b),yy+.011*math.sin(b),zz2],.0012,1,6)
 for j in range(count):
  z=0 if count==1 else -.27+j*.54/(count-1)
  part('Jugador_'+str(idx)+'_'+str(j),[x*.65,.92,z*.7])
  sphere([x,.95,z],.017,col);box([x,.91,z],[.028,.045,.031],col);box([x,.864,z],[.022,.052,.025],col);box([x+.006,.839,z],[.035,.013,.03],col)
# external goals: rectangular metal frame and black woven net
for s in [-1,1]:
 part('Porteria_'+str(s),[s*.78,.25,0])
 a=s*.665;b=s*.815
 for x in [a,b]:
  for y in [.785,.91]:cyl([x,y,-.155],[x,y,.155],.004,1)
  for z in [-.155,.155]:cyl([x,.785,z],[x,.91,z],.004,1)
 for z in [-.155,.155]:
  for y in [.785,.91]:cyl([a,y,z],[b,y,z],.004,1)
  for i in range(7):
   x=a+(b-a)*i/6;cyl([x,.785,z],[x,.91,z],.0018,2,6)
  for i in range(6):
   y=.785+i*.025;cyl([a,y,z],[b,y,z],.0018,2,6)
 for i in range(14):
  z=-.155+i*.31/13;cyl([b,.785,z],[b,.91,z],.0018,2,6);cyl([a,.785,z],[b,.785,z],.0018,2,6)
 for i in range(6):
  y=.785+i*.025;cyl([b,y,-.155],[b,y,.155],.0018,2,6)
part('Balon',[0,1.20,0])
sphere([.29,.827,.11],.02,5)
# glTF 2 binary export
blob=bytearray();views=[];access=[];meshes=[];nodes=[]
def add(data,typ,component,count,mins=None,maxs=None):
 while len(blob)%4:blob.append(0)
 off=len(blob);blob.extend(data);vi=len(views);views.append({'buffer':0,'byteOffset':off,'byteLength':len(data)})
 ac={'bufferView':vi,'componentType':component,'count':count,'type':typ}
 if mins is not None:ac.update(min=mins,max=maxs)
 access.append(ac);return len(access)-1
roots=[];animation_samplers=[];animation_channels=[]
times=add(struct.pack('<2f',0,3),'SCALAR',5126,2,[0],[3])
for name,partdata in parts.items():
 if not partdata['groups']:continue
 primitives=[]
 for m,(v,n,f) in partdata['groups'].items():
  assert len(v)==len(n) and max(f)<len(v)
  flat=lambda a:[x for q in a for x in q]
  pos=add(struct.pack('<%sf'%(len(v)*3),*flat(v)),'VEC3',5126,len(v),[min(q[i] for q in v) for i in range(3)],[max(q[i] for q in v) for i in range(3)])
  norm=add(struct.pack('<%sf'%(len(n)*3),*flat(n)),'VEC3',5126,len(n))
  ind=add(struct.pack('<%sI'%len(f),*f),'SCALAR',5125,len(f))
  primitives.append({'attributes':{'POSITION':pos,'NORMAL':norm},'indices':ind,'material':m})
 mi=len(meshes);meshes.append({'name':name,'primitives':primitives})
 ni=len(nodes);nodes.append({'mesh':mi,'name':name,'translation':[0,0,0],'extras':{'explode':partdata['offset'],'part':True}});roots.append(ni)
 vals=add(struct.pack('<6f',0,0,0,*partdata['offset']),'VEC3',5126,2)
 animation_samplers.append({'input':times,'output':vals,'interpolation':'LINEAR'})
 animation_channels.append({'sampler':len(animation_samplers)-1,'target':{'node':ni,'path':'translation'}})
doc={'asset':{'version':'2.0','generator':'Herraidea parts reconstruction','extras':{'note':'Approximate photo-based geometry. Exploded animation for presentation, not mechanical assembly instructions.'}},'scene':0,'scenes':[{'nodes':roots}],'nodes':nodes,'meshes':meshes,'materials':materials,'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':access,'animations':[{'name':'Despiece','samplers':animation_samplers,'channels':animation_channels}],'extensionsUsed':['KHR_materials_transmission','KHR_materials_ior','KHR_materials_volume']}
print(len(roots),'independently addressable parts; embedded Despiece animation')
j=json.dumps(doc,separators=(',',':'),ensure_ascii=True).encode();j+=b' '*((-len(j))%4);blob+=b'\0'*((-len(blob))%4)
raw=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
(P/'futbolito-herraidea.glb').write_bytes(raw)
assert struct.unpack_from('<I',raw,8)[0]==len(raw)
print('GLB:',len(raw),'bytes;',sum(len(g[2])//3 for g in groups.values()),'triangles')
