# Futbolito de cristal de Herraidea — modelo y despiece

## Contenido
- futbolito-herraidea.glb: geometría 3D, 190 nodos independientes (piezas y conjuntos), materiales PBR, vidrio con transmisión y animación Despiece.
- visor.html: demostración con Despiece, Armar, Ver costado y un deslizador de separación. El modelo está integrado en este HTML; requiere conexión para cargar Three.js y sus dependencias.
- generar.py: generador editable, Python estándar.

## Probar
Abre visor.html en un navegador con WebGL. Si el navegador bloquea módulos al abrir un archivo local, sirve esta carpeta con `python3 -m http.server 8000` y abre http://localhost:8000/visor.html.

## Integrar en la web
El GLB tiene una animación llamada Despiece, de 0 a 3 segundos: 0 es armado y 3 es separado. Se puede recorrer hacia delante, hacia atrás o vincular su tiempo al scroll. En Three.js, después de cargar el GLB:

```js
const mixer = new THREE.AnimationMixer(gltf.scene);
const action = mixer.clipAction(gltf.animations.find(a => a.name === 'Despiece'));
action.play();
action.paused = true;
function setDespiece(progreso) {
  action.time = Math.max(0, Math.min(1, progreso)) * 3;
  mixer.update(0);
}
```

Renderiza la escena tras cada actualización. Interpola progreso de 1 a 0 para armarlo. Cada nodo lleva nombre y extras.explode con su desplazamiento de presentación, y puede animarse individualmente. Las marcas esmeriladas se mueven con el cristal de la cancha. Los jugadores, resortes y porterías se conservan como conjuntos; tapas, juntas, mangos, barras y herrajes están separados. No representa tornillería interna ni componentes ocultos que no aparecen en las fotos.

## Fidelidad y validación
Reconstrucción visual aproximada a partir de fotografías, sin medidas confirmadas. Se han aplicado esquinas de vidrio achaflanadas, separación de paños, cabeceras de una pieza con recorte inferior, herrajes superiores y pipetas a 90 grados. No es un modelo de fabricación ni una secuencia física de montaje: el despiece es una animación de presentación.

Se comprobaron índices, buffers, geometría y canales de animación, y la sintaxis JavaScript. No se ha verificado la ejecución del visor en un navegador en este entorno. Aún no está instalado ni publicado en la web de Herraidea.

Ambos cristales laterales son una sola pieza continua, con recorte inferior redondeado, un nodo y un canal de animación por costado.
