# Herraidea · Despiece conceptual de pinza para cristal

Incluye herraje-cristal.glb, visor.html y generar.py. El modelo tiene 46 nodos independientes y un clip Despiece de 0 a 3 segundos. En 0 está armado; en 3, separado. El visor permite despiece, armado, acercamiento a una pinza y control manual del avance. Usa Three.js por CDN y requiere conexión a Internet.

Abre visor.html en un navegador con WebGL. Si bloquea módulos locales, sirve la carpeta con `python3 -m http.server 8000` y abre http://localhost:8000/visor.html.

## Qué representa
Tramo recto completo: dos postes con sus bases, cuatro pinzas en forma de D (dos superiores y dos inferiores), un paño central de cristal, dos soportes superiores y un pasamanos continuo. Cada poste y su base forman un conjunto. El vidrio muestra su ubicación, no un espesor especificado. El interior del poste y los detalles de fundición y roscas se simplificaron. La tornillería se basa en lo visible en las fotos y no es una lista comercial completa de componentes.

## Para integrar y animar
Cargar el GLB con GLTFLoader. Crear AnimationMixer(gltf.scene), obtener el clip Despiece, ejecutar action.play(), establecer action.paused=true y actualizar action.time entre 0 y 3 con mixer.update(0). Recorrer de 3 a 0 para armar. Cada nodo tiene extras.explode con su desplazamiento y puede animarse individualmente.

## Estado de revisión
Borrador conceptual para revisar con Herraidea. Proporciones aproximadas, sin planos de fabricante. No es un instructivo de instalación aprobado. Faltan confirmar modelo/SKU, dimensiones, espesores admitidos, material exacto de empaques, anclajes, carga y aprietes. Las imágenes generadas son propuestas gráficas: pueden alterar la fijación y no deben usarse como evidencia técnica. La ficha de referencia utiliza otras marcas y especificaciones que no se trasladaron a este producto.

Los buffers, canales de animación y sintaxis JavaScript se validaron; no se ha probado el visor en navegador en este entorno. No se ha publicado en la web.

Actualizado con fotografías del producto terminado. Las referencias en esquina y escalera son contexto de uso; este archivo representa un tramo recto. Paleta confirmada visualmente con el logo proporcionado: rojo y gris.

Corrección: la pared recta de montaje y la mordaza posterior se desplazan juntas como un solo conjunto. Se conservaron las dimensiones originales del modelo, sin reducir la placa. Las medidas siguen siendo aproximadas a partir de fotografías.
