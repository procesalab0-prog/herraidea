import math,struct,json,pathlib,zipfile
P=pathlib.Path(__file__).parent
materials=[{'name':'Cristal transparente','pbrMetallicRoughness':{'baseColorFactor':[.90,.98,.96,1],'metallicFactor':0,'roughnessFactor':.07},'doubleSided':True,'extensions':{'KHR_materials_transmission':{'transmissionFactor':.97},'KHR_materials_ior':{'ior':1.5},'KHR_materials_volume':{'thicknessFactor':.012,'attenuationDistance':1.8,'attenuationColor':[.60,.92,.79]}}}, {'name':'Acero inoxidable','pbrMetallicRoughness':{'baseColorFactor':[.7,.73,.75,1],'metallicFactor':1,'roughnessFactor':.22}}, {'name':'Negro','pbrMetallicRoughness':{'baseColorFactor':[.016,.019,.022,1],'roughnessFactor':.43}}, {'name':'Blanco','pbrMetallicRoughness':{'baseColorFactor':[.91,.91,.88,1],'roughnessFactor':.32}}, {'name':'Lineas esmeriladas','pbrMetallicRoughness':{'baseColorFactor':[.7,.76,.73,1],'roughnessFactor':.8}}, {'name':'Balon naranja','pbrMetallicRoughness':{'baseColorFactor':[1,.19,.015,1],'roughnessFactor':.4}}]
groups={i:[[],[],[]] for i in range(6)}
parts={};active='';split=False;serial=0

def part(name,offset,separate=False):
 global active,split
 active=name;split=separate
 if name not in parts:parts[name]={'offset':offset,'groups':{}}

def mesh_part(v,n,f,m):
 global serial
 key=active
 if split:
  serial+=1;key=active+'_'+str(serial)
  center=[sum(q[i] for q in v)/len(v) for i in range(3)]
  off=parts[active]['offset']
  parts[key]={'offset':[off[i]+(center[i]-[0,.5,0][i])*.15 for i in range(3)],'groups':{}}
 d=parts[key]['groups'].setdefault(m,[[],[],[]]);k=len(d[0]);d[0].extend(v);d[1].extend(n);d[2].extend([k+i for i in f])

def mesh(v,n,f,m):
 mesh_part(v,n,f,m)
 a,b,c=groups[m]; k=len(a);a.extend(v);b.extend(n);c.extend([k+i for i in f])
def box(center,size,m):
 v=[];n=[];f=[]
 for ax in range(3):
  u=(ax+1)%3;w=(ax+2)%3
  for s in [-1,1]:
   k=len(v)
   for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]:
    q=list(center);q[ax]+=s*size[ax]/2;q[u]+=a*size[u]/2;q[w]+=b*size[w]/2;v.append(q);nn=[0,0,0];nn[ax]=s;n.append(nn)
   f.extend([k,k+1,k+2,k,k+2,k+3] if s==1 else [k,k+2,k+1,k,k+3,k+2])
 mesh(v,n,f,m)
def cyl(a,b,r,m,N=20):
 d=[b[i]-a[i] for i in range(3)];L=math.sqrt(sum(x*x for x in d));d=[x/L for x in d];t=[1,0,0] if abs(d[0])<.9 else [0,1,0]
 def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
 u=cross(d,t);l=math.sqrt(sum(x*x for x in u));u=[x/l for x in u];w=cross(d,u);v=[];n=[];f=[]
 for p in [a,b]:
  for j in range(N):
   t=2*math.pi*j/N;nn=[u[i]*math.cos(t)+w[i]*math.sin(t) for i in range(3)];v.append([p[i]+r*nn[i] for i in range(3)]);n.append(nn)
 for j in range(N):
  k=(j+1)%N;f.extend([j,k,N+k,j,N+k,N+j])
 for end,p in enumerate([a,b]):
  c=len(v);v.append(p);n.append([x*(2*end-1) for x in d])
  for j in range(N):
   k=(j+1)%N;f.extend([c,end*N+k,end*N+j] if end==0 else [c,end*N+j,end*N+k])
 mesh(v,n,f,m)
def sphere(c,r,m):
 v=[];n=[];f=[];N=20;R=12
 for i in range(R+1):
  t=math.pi*i/R
  for j in range(N+1):
   p=2*math.pi*j/N;q=[math.sin(t)*math.cos(p),math.cos(t),math.sin(t)*math.sin(p)];n.append(q);v.append([c[k]+r*q[k] for k in range(3)])
 for i in range(R):
  for j in range(N):
   k=i*(N+1)+j;f.extend([k,k+N+1,k+1,k+1,k+N+1,k+N+2])
 mesh(v,n,f,m)
def line(a,b):cyl(a,b,.002,4,8)
def prism(poly,axis,center,thickness,m):
 # Convex polygon extrusion; ordered counterclockwise in plane coordinates.
 u=(axis+1)%3;w=(axis+2)%3
 def point(q,t):
  v=[0,0,0];v[axis]=t;v[u]=q[0];v[w]=q[1];return v
 for sign in [-1,1]:
  v=[point(q,center+sign*thickness/2) for q in poly];n=[[sign if i==axis else 0 for i in range(3)]]*len(v);f=[]
  for j in range(1,len(v)-1):f.extend([0,j,j+1] if sign>0 else [0,j+1,j])
  mesh(v,n,f,m)
 for a,b in zip(poly,poly[1:]+poly[:1]):
  du=b[0]-a[0];dw=b[1]-a[1];l=math.hypot(du,dw);nn=[0,0,0];nn[u]=dw/l;nn[w]=-du/l
  v=[point(a,center-thickness/2),point(b,center-thickness/2),point(b,center+thickness/2),point(a,center+thickness/2)]
  mesh(v,[nn]*4,[0,1,2,0,2,3],m)
def chamfer_rect(a,b,c,d,r):
 return [(a+r,c),(b-r,c),(b,c+r),(b,d-r),(b-r,d),(a+r,d),(a,d-r),(a,c+r)]
# Approximate photo-based dimensions in metres; no installation specification.
materials[3]['name']='Empaque translúcido'
materials[3]['pbrMetallicRoughness']['baseColorFactor']=[.82,.84,.88,1]
def screw(a,b,r=.0025):
 cyl(a,b,r,1,20)
 d=[b[i]-a[i] for i in range(3)];L=math.sqrt(sum(t*t for t in d));d=[t/L for t in d]
 end=[b[i]+d[i]*.002 for i in range(3)];cyl(b,end,r*1.8,1,32)
 cyl(end,[end[i]+d[i]*.0001 for i in range(3)],r*.8,2,6)
def profile(side,cy):
 pts=[(.031,cy-.030),(.063,cy-.030)]
 for i in range(1,33):
  a=-math.pi/2+i*math.pi/32;pts.append((.063+.03*math.cos(a),cy+.03*math.sin(a)))
 pts.append((.031,cy+.03))
 return pts if side>0 else [(-x,y) for x,y in pts][::-1]
part('Poste_y_base',[0,0,0]);cyl([0,.006,0],[0,.55,0],.025,1,64);cyl([0,0,0],[0,.006,0],.05,1,64)
part('Casquillo_superior',[0,.035,0]);cyl([0,.55,0],[0,.58,0],.011,1,48)
part('Vastago_regulable',[0,.075,0]);cyl([0,.565,0],[0,.637,0],.007,1,48)
part('Prisionero_regulacion',[.035,.035,0]);screw([.008,.565,0],[.014,.565,0],.0018)
part('Eje_articulacion',[0,.075,.03]);screw([0,.635,-.01],[0,.635,.01],.0025)
part('Cuna_pasamanos',[0,.125,0]);box([0,.638,0],[.012,.014,.014],1)
for i in range(24):
 za=-.016+i*.032/24;zb=za+.032/24
 for j in range(36):
  xa=-.03+j*.06/36;xb=xa+.06/36;xc=(xa+xb)/2;zc=(za+zb)/2
  if any((xc-h)**2+zc**2<.003**2 for h in [-.018,.018]):continue
  ya=.644+(za/.016)**2*.005;yb=.644+(zb/.016)**2*.005
  v=[[xa,ya,za],[xb,ya,za],[xb,yb,zb],[xa,yb,zb]];mesh(v,[[0,1,0]]*4,[0,2,1,0,3,2],1)
for side in [-1,1]:
 cy=.425;tag='izquierda' if side<0 else 'derecha'
 part('Base_pinza_'+tag,[side*.05,0,0]);box([side*.028,cy,0],[.006,.062,.024],1)
 part('Fijacion_al_poste_'+tag,[side*.10,0,0]);screw([side*.020,cy,0],[side*.048,cy,0],.003)
 for front in [-1,1]:
  face='frontal' if front>0 else 'posterior';z=front*.010;poly=profile(side,cy)
  part('Mordaza_'+face+'_'+tag,[side*.08,0,front*.06]);prism(poly,2,z,.0025,1)
  for a,b in zip(poly,poly[1:]+poly[:1]):cyl([a[0],a[1],z-front*.002],[b[0],b[1],z-front*.002],.0014,1,8)
  for y in [cy-.019,cy+.019]:cyl([side*.044,y,z],[side*.044,y,z-front*.005],.004,1,24)
  box([side*.036,cy,z-front*.003],[.01,.007,.004],1)
  part('Empaque_'+face+'_'+tag,[side*.08,0,front*.03])
  for i in range(64):
   a=i*math.tau/64;b=(i+1)*math.tau/64
   cyl([side*(.068+.021*math.cos(a)),cy+.025*math.sin(a),front*.0055],[side*(.068+.021*math.cos(b)),cy+.025*math.sin(b),front*.0055],.002,3,10)
 for k,y in enumerate([cy-.019,cy+.019]):
  part('Tornillo_cierre_'+tag+'_'+str(k+1),[side*.08,0,.10]);screw([side*.044,y,-.011],[side*.044,y,.014],.0024)
 part('Prisionero_central_'+tag,[side*.08,0,.075]);screw([side*.036,cy,.006],[side*.036,cy,.013],.0017)
 part('Cristal_ilustrativo_'+tag,[side*.20,0,0]);box([side*.161,.325,0],[.20,.37,.007],0)
# The straight mounting wall belongs to the rear D-shaped jaw.
# Preserve original dimensions and placement; move both as one rigid assembly.
for tag in ['izquierda','derecha']:
 base=parts.pop('Base_pinza_'+tag)
 jaw=parts['Mordaza_posterior_'+tag]
 for material,(vertices,normals,indices) in base['groups'].items():
  target=jaw['groups'].setdefault(material,[[],[],[]])
  start=len(target[0])
  target[0].extend(vertices);target[1].extend(normals)
  target[2].extend(i+start for i in indices)
# Complete reference bay: two end posts, four inward-facing clamps,
# a single central glass pane and a continuous handrail.
source=parts;parts={}
def clone_part(name,data,dx=0,dy=0,scale_y=1,offset=None):
 groups_copy={}
 for m,(v,n,f) in data['groups'].items():
  groups_copy[m]=[[[q[0]+dx,q[1]*scale_y+dy,q[2]] for q in v],[list(q) for q in n],list(f)]
 parts[name]={'groups':groups_copy,'offset':offset or list(data['offset'])}
post_prefix=('Poste_y_base','Casquillo_superior','Vastago_regulable','Prisionero_regulacion','Eje_articulacion','Cuna_pasamanos')
for label,px,inward in [('izquierdo',-.48,'derecha'),('derecho',.48,'izquierda')]:
 outward=math.copysign(1,px)
 for name,data in source.items():
  if name.startswith(post_prefix):
   off=[outward*.18,data['offset'][1]*2,data['offset'][2]]
   clone_part(label+'_'+name,data,px,0,1.5,off)
 for height,cy in [('superior',.695),('inferior',.17)]:
  for name,data in source.items():
   if inward not in name or name.startswith('Cristal_'):continue
   off=[outward*.10, .08 if height=='superior' else -.04, data['offset'][2]*2]
   clone_part(label+'_'+height+'_'+name,data,px,cy-.425,1,off)
part('Cristal_central',[0,.08,.28]);box([0,.435,0],[.838,.71,.007],0)
part('Pasamanos_continuo',[0,.32,0]);cyl([-.555,.986,0],[.555,.986,0],.022,1,64)
# glTF 2 binary export
blob=bytearray();views=[];access=[];meshes=[];nodes=[]
def add(data,typ,component,count,mins=None,maxs=None):
 while len(blob)%4:blob.append(0)
 off=len(blob);blob.extend(data);vi=len(views);views.append({'buffer':0,'byteOffset':off,'byteLength':len(data)})
 ac={'bufferView':vi,'componentType':component,'count':count,'type':typ}
 if mins is not None:ac.update(min=mins,max=maxs)
 access.append(ac);return len(access)-1
roots=[];animation_samplers=[];animation_channels=[]
times=add(struct.pack('<2f',0,3),'SCALAR',5126,2,[0],[3])
for name,partdata in parts.items():
 if not partdata['groups']:continue
 primitives=[]
 for m,(v,n,f) in partdata['groups'].items():
  assert len(v)==len(n) and max(f)<len(v)
  flat=lambda a:[x for q in a for x in q]
  pos=add(struct.pack('<%sf'%(len(v)*3),*flat(v)),'VEC3',5126,len(v),[min(q[i] for q in v) for i in range(3)],[max(q[i] for q in v) for i in range(3)])
  norm=add(struct.pack('<%sf'%(len(n)*3),*flat(n)),'VEC3',5126,len(n))
  ind=add(struct.pack('<%sI'%len(f),*f),'SCALAR',5125,len(f))
  primitives.append({'attributes':{'POSITION':pos,'NORMAL':norm},'indices':ind,'material':m})
 mi=len(meshes);meshes.append({'name':name,'primitives':primitives})
 ni=len(nodes);nodes.append({'mesh':mi,'name':name,'translation':[0,0,0],'extras':{'explode':partdata['offset'],'part':True}});roots.append(ni)
 vals=add(struct.pack('<6f',0,0,0,*partdata['offset']),'VEC3',5126,2)
 animation_samplers.append({'input':times,'output':vals,'interpolation':'LINEAR'})
 animation_channels.append({'sampler':len(animation_samplers)-1,'target':{'node':ni,'path':'translation'}})
doc={'asset':{'version':'2.0','generator':'Herraidea parts reconstruction','extras':{'note':'Approximate photo-based geometry. Exploded animation for presentation, not mechanical assembly instructions.'}},'scene':0,'scenes':[{'nodes':roots}],'nodes':nodes,'meshes':meshes,'materials':materials,'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':access,'animations':[{'name':'Despiece','samplers':animation_samplers,'channels':animation_channels}],'extensionsUsed':['KHR_materials_transmission','KHR_materials_ior','KHR_materials_volume']}
print(len(roots),'independently addressable parts; embedded Despiece animation')
j=json.dumps(doc,separators=(',',':'),ensure_ascii=True).encode();j+=b' '*((-len(j))%4);blob+=b'\0'*((-len(blob))%4)
raw=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
(P/'herraje-cristal.glb').write_bytes(raw)
assert struct.unpack_from('<I',raw,8)[0]==len(raw)
print('GLB:',len(raw),'bytes;',sum(len(g[2])//3 for g in groups.values()),'triangles')
