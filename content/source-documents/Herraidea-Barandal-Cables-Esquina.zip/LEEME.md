# Herraidea · Barandal de cables · Esquina propuesta

Reconstrucción visual del video de 30.94 segundos. Postes cuadrados negros, bases cuadradas al piso, vástagos superiores y pasamanos rectangular metálico. Cables delgados con terminales de ajuste, sin pines de paso del producto anterior. No se identificó SKU.

La esquina es una propuesta porque el video muestra un tramo recto: tres postes y dos tramos a 90 grados. Pasamanos con encuentro a inglete; terminales independientes en caras perpendiculares del poste central. Se propone un desfase de 12 mm entre alturas de ambos tramos para evitar interferencia de terminales interiores; no es un detalle confirmado por fabricante. Ocho cables por tramo en el borrador, cantidad a confirmar. Dimensiones ilustrativas, interiores y roscas simplificados. No es un plano de fabricación ni guía de instalación.

Incluye GLB con 103 piezas/conjuntos y animación Despiece de 0 a 3 segundos, visor.html y generar.py. Visor requiere Internet y WebGL. Cargar GLB con GLTFLoader y controlar clip Despiece mediante AnimationMixer. 0 armado, 3 separado; cada nodo incluye extras.explode. Se revisaron estructura, animación, sintaxis y vista geométrica; no probado en navegador.
